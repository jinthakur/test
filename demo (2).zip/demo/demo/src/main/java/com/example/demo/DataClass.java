package com.example.demo;

public record DataClass(long id, String content) { }